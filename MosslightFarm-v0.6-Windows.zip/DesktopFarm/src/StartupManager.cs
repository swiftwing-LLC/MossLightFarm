using System;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;
using System.Web.Script.Serialization;
namespace DesktopFarm {
public static class StartupManager {
 const string RunKey=@"Software\Microsoft\Windows\CurrentVersion\Run",ValueName="Mosslight Farm";
 static DateTime lastEngineAttempt=DateTime.MinValue;
 public static string StartupCommand(string exe){return "\""+exe.Replace("\"","")+"\" --startup";}
 public static bool Enabled {get{try{using(var key=Registry.CurrentUser.OpenSubKey(RunKey)){return key!=null&&Convert.ToString(key.GetValue(ValueName))==StartupCommand(System.Windows.Forms.Application.ExecutablePath);}}catch{return false;}}}
 public static void SetEnabled(bool enabled){using(var key=Registry.CurrentUser.CreateSubKey(RunKey)){if(enabled)key.SetValue(ValueName,StartupCommand(System.Windows.Forms.Application.ExecutablePath));else key.DeleteValue(ValueName,false);}}
 public static bool EnsureEngine(){if(WallpaperEngineHost.FindEngine()!=null)return true;if((DateTime.UtcNow-lastEngineAttempt).TotalSeconds<15)return false;lastEngineAttempt=DateTime.UtcNow;
  string file="";try{string session=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"MosslightFarm","web-wallpaper","session.json");if(File.Exists(session))file=new JavaScriptSerializer().Deserialize<WallpaperEngineHost.Session>(File.ReadAllText(session)).Engine;}catch{}
  if(string.IsNullOrEmpty(file)||!File.Exists(file))file=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam","steamapps","common","wallpaper_engine","wallpaper64.exe");
  if(!File.Exists(file))return false;try{Process.Start(new ProcessStartInfo(file){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=Path.GetDirectoryName(file)});}catch{}return false;
 }
}
}

using System;
using System.IO;
using System.Web.Script.Serialization;
namespace DesktopFarm {
public static class V06Tests {
 public static void Run(string path,Action<bool,string> check){
 check(StartupManager.StartupCommand(@"C:\Users\A & B\Farm\MosslightFarm.exe")=="\"C:\\Users\\A & B\\Farm\\MosslightFarm.exe\" --startup","Startup command quotes paths with spaces and ampersands");
 check(WallpaperEngineHost.ShouldRecover(31,121,true,true),"Stalled visible farm schedules recovery");
 check(!WallpaperEngineHost.ShouldRecover(31,121,false,true),"Paused hidden wallpaper does not trigger recovery");
 check(!WallpaperEngineHost.ShouldRecover(31,121,true,false),"Recovery never overrides a different wallpaper");
 check(!WallpaperEngineHost.ShouldRecover(31,90,true,true),"Recovery backs off instead of reopening repeatedly");
 check(!WallpaperEngineHost.ShouldRecover(10,121,true,true),"Healthy wallpaper is not restarted");
 var f=new Farm(()=>2000000000);using(var scene=new WallpaperForm(f,s=>{},()=>{},true)){
 foreach(string weather in new[]{"晴天","雨天","雪天"}){DesktopHud.Apply(f,scene,new DesktopHud.Command{action="weather",id=weather});check(LandscapeArt.Weather(f)==weather,"Weather selection applies: "+weather);}
 DesktopHud.Apply(f,scene,new DesktopHud.Command{action="weather",id="invalid"});check(f.S.Weather=="雪天","Invalid weather cannot overwrite preference");
 string file=Path.Combine(path,"weather.json");f.Save(file);var copy=new Farm(()=>2000000000);copy.Load(file);check(copy.S.Weather=="雪天","Weather preference survives restart");
 foreach(string lighting in new[]{"白天","夜晚"})foreach(string weather in new[]{"晴天","雨天","雪天"}){f.S.Lighting=lighting;f.S.Weather=weather;string before=new JavaScriptSerializer().Serialize(f.S);using(var frame=scene.SceneSnapshot(960,540)){check(frame.Width==960&&frame.GetPixel(0,0).A==255,"Day/night weather scene has an opaque background");}check(new JavaScriptSerializer().Serialize(f.S)==before,"Atmospheric rendering preserves economy and layout");}
 }
 }
}
}

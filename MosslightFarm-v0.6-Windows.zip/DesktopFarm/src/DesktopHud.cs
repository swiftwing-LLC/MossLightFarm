using System;
using System.Linq;
namespace DesktopFarm {
// The wallpaper and management window use the same authoritative farm model.
public static class DesktopHud {
 public class Command {public string action {get;set;}public string id {get;set;}}
 public static object State(Farm f,WallpaperForm scene,string panel,int revision,bool startup=false,bool startupAllowed=true){return new {
  startup=startup,startupAllowed=startupAllowed,weather=f.S.Weather,zoom=f.S.HudZoom,coins=f.S.Coins,level=f.Level,xp=f.S.Xp-Farm.Threshold(f.Level),xpMax=f.Level>=20?0:Farm.Threshold(f.Level+1)-Farm.Threshold(f.Level),language=f.S.Language,seed=f.S.SelectedSeed,edit=scene.EditMode,pending=scene.PendingName,note=scene.CurrentNote,panel=panel,revision=revision,
  ready=f.S.Plots.Count(p=>p.Crop!=""&&p.Ready<=f.Now),empty=f.S.Plots.Count(p=>p.Crop==""),land=f.S.Plots.Count,expandCost=f.ExpandCost,canExpand=f.S.Land<2&&f.Level>=(f.S.Land==0?2:5)&&f.S.Coins>=f.ExpandCost,
  crops=Farm.Crops.Select(c=>new{id=c.Id,name=L.T(c.Name),cost=c.Cost,seconds=c.Seconds,level=c.Level,owned=f.Count(c.Id)}).ToArray(),
  inventory=f.S.Inventory.Where(p=>p.Value>0).Select(p=>new{id=p.Key,name=L.T(Farm.ItemName(p.Key)),count=p.Value,price=Farm.Price(p.Key)}).ToArray(),
  recipes=Farm.Recipes.Select(r=>new{id=r.Id,name=L.T(r.Name),seconds=r.Seconds,building=L.T(Farm.BuildingName(r.Building)),level=r.Level,can=f.Has(r.Building)&&f.Level>=r.Level&&f.Queue(r.Building).Count<f.S.Buildings[r.Building]+1&&r.Inputs.All(p=>f.Count(p.Key)>=p.Value),ingredients=string.Join(" · ",r.Inputs.Select(p=>L.T(Farm.ItemName(p.Key))+" "+f.Count(p.Key)+"/"+p.Value))}).ToArray(),
  jobs=f.S.Queues.SelectMany(q=>q.Value.Select(j=>new{name=L.T(Farm.ItemName(j.Recipe)),seconds=Math.Max(0,j.Ready-f.Now)})).ToArray(),
  orders=f.S.OrdersList.Select((o,i)=>new{id=i,name=L.T(o.Person),coins=o.Coins,xp=o.Xp,can=f.CanOrder(o),items=string.Join(" · ",o.Items.Select(p=>L.T(Farm.ItemName(p.Key))+" "+f.Count(p.Key)+"/"+p.Value))}).ToArray(),
  buildings=Farm.BuildingIds.Select((id,i)=>new{id=id,name=L.T(Farm.BuildingName(id)),owned=f.Has(id),level=Farm.BuildingLevels[i],cost=f.Has(id)?f.S.Buildings[id]*160:Farm.BuildingCosts[i],can=f.Has(id)?f.S.Buildings[id]<3&&id!="coop"&&id!="barn"&&id!="station"&&f.S.Coins>=f.S.Buildings[id]*160:f.Level>=Farm.BuildingLevels[i]&&f.S.Coins>=Farm.BuildingCosts[i]}).ToArray(),
  decor=new[]{"path","flowers","fence","lamp","bench","tree","fountain"}.Select(id=>new{id=id,name=L.T(Farm.DecorName(id)),cost=Farm.DecorCost(id)}).ToArray(),guide=L.T(f.GuideTitle),guideDone=f.GuideDone,lighting=f.S.Lighting
 };}
 public static string Apply(Farm f,WallpaperForm scene,Command c){if(c==null)return "";switch(c.action){
  case "zoom":int zoom;if(int.TryParse(c.id,out zoom)&&new[]{85,100,125,150}.Contains(zoom))f.S.HudZoom=zoom;return "";
  case "seed":var crop=Farm.Crop(c.id);if(crop!=null&&crop.Level<=f.Level)f.S.SelectedSeed=c.id;return "";
  case "harvest":return f.HarvestAll();case "plant":return f.PlantAll(f.S.SelectedSeed);
  case "sell":return f.Count(c.id)>0?f.Sell(c.id,1):"";
  case "craft":return Farm.GetRecipe(c.id)!=null?f.Craft(c.id):"";
  case "order":int index;if(int.TryParse(c.id,out index))return f.Deliver(index);return "";
  case "build":return Array.IndexOf(Farm.BuildingIds,c.id)>=0?f.BuyBuilding(c.id):"";
  case "expand":return f.Expand();case "guide":return f.ClaimGuide();case "daily":return f.Daily();
  case "edit":scene.ClientInput("toggle",0,0);return "";
  case "decor":if(new[]{"path","flowers","fence","lamp","bench","tree","fountain"}.Contains(c.id))scene.ChooseDecoration(c.id);return "";
  case "cancel":scene.ClientInput("cancel",0,0);return "";
  case "language":f.S.Language=c.id=="en"?"en":"zh-CN";L.SetLanguage(f.S.Language);return "";
  case "weather":if(new[]{"自动","晴天","雨天","雪天"}.Contains(c.id))f.S.Weather=c.id;return "";
  case "light":if(new[]{"白天","夜晚","跟随时间"}.Contains(c.id))f.S.Lighting=c.id;return "";
  case "call":scene.CallAnimals();return "";
 }return "";}
}
}

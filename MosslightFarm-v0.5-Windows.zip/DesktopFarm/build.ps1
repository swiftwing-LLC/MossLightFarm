$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$sourceFiles = Get-ChildItem -LiteralPath (Join-Path $projectRoot 'src') -Filter '*.cs' | ForEach-Object { $_.FullName }
$target = Join-Path $projectRoot 'MosslightFarm.exe'
$compilerArgs = @('/nologo', '/target:winexe', '/optimize+', '/platform:anycpu', '/utf8output', '/r:System.Drawing.dll', '/r:System.Windows.Forms.dll', '/r:System.Web.Extensions.dll', "/out:$target")
$iconPath = Join-Path $projectRoot 'assets\farm.ico'
if (Test-Path -LiteralPath $iconPath) { $compilerArgs += "/win32icon:$iconPath" }
$compilerArgs += "/win32manifest:$(Join-Path $projectRoot 'app.manifest')"
& $compiler @compilerArgs @sourceFiles
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
Write-Output "Built $target"

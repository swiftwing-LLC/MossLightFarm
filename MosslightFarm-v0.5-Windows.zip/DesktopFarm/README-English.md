# Mosslight Desktop Farm · v0.5

The desktop interface is larger and scales with the viewport. Open the corner gear → Interface size to choose 85%, Auto, 125% or 150%. Preferences persist; smaller screens wrap the dock and cap oversized zoom. Seven viewport sizes, including 640×480, 4K and portrait, were checked in Chinese and English. Mixed-DPI monitor configurations have not all been tested on hardware.

Drag the actual object directly: no selection rectangle or duplicate left behind. Release saves the move; invalid overlaps return the object to its previous position. Esc/right-click cancels a drag.

A playable pixel farm on your Windows desktop. **Wallpaper Engine and Mosslight Farm must both be running for live wallpaper mode.** Management also works as a standalone window.

Run `MosslightFarm.exe` with the adjacent `assets` folder. Switch Chinese / English on the welcome screen or in Settings. Choose **Use as desktop**, then return to the Windows desktop.

Currency, level and XP now stay visible in a compact corner bar. The bottom dock opens Seeds, Storage, Workshop, Orders, Build and Arrange as small panels inside the wallpaper. Selling, crafting, deliveries, expansion and language changes no longer require the management window. Text is rendered separately from the pixel scene, so it stays compact and readable.

- **Click a plot directly** to plant, harvest or water. No Alt key is needed.
- **Click companions** to pet them, or feed/collect from farm animals.
- **Drag any owned building, plot, pond, tree, fence or decoration** to move it. Layout is saved; moving preserves crop timers and does not cost money. Solid objects cannot overlap.
- **Arrange** opens the decoration palette with actual game sprites. Select an item, then click a spot to buy and place it. The compact mode bar offers **Cancel** or **Finish arranging**. Cancelling before placement costs nothing.
- **Ctrl + Alt + F**, the wheat tray icon or running the game again opens management.
- **Restore desktop** stops the farm wallpaper. **Save and quit** restores the previously selected Wallpaper Engine wallpaper.

While the wallpaper is active, the tray's arrangement command also opens the inline wallpaper panel. The older management window is optional. Esc or right-click cancels pending placement. Management shows a compact farming overview; the wallpaper uses your custom arrangement.

Start by harvesting wheat, replanting, milling flour, and fulfilling orders. Nine crops, nine recipes, four production animals, a cat/dog companion, decorations, land expansion and offline progress are included. Mature crops never wither.

Progress is saved after actions and every 15 seconds to `%LOCALAPPDATA%\MosslightFarm\save.json`, with a `.bak` backup. Layout changes and language choices persist. The wallpaper runtime is generated under `Documents\MosslightFarm\web-wallpaper`; keep those files in place while playing. The live connection stays on 127.0.0.1; no account or internet access is required.

Wallpaper Engine may pause animation when another application is focused, maximized or fullscreen, according to its Performance settings. Returning to the desktop should resume it. Farming timers continue by real elapsed time. This release is single-player; it does not provide online co-op or trading.

All game art and music are original project assets. C# sources are included. Exit the game and run `build.ps1` to rebuild. `--self-test <folder>` runs isolated rule, layout and interaction checks; `--qa <folder>` uses a separate test farm.

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
namespace DesktopFarm {
public class WallpaperLease:IDisposable {
 public class Record {public string Original="",Applied="",Engine="";public bool Active;}
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool SystemParametersInfo(uint action,uint param,string value,uint flags);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="SystemParametersInfoW")]static extern bool ReadWallpaper(uint action,uint param,StringBuilder value,uint flags);
 readonly string folder,recordPath;Record record;bool active;int revision;
 public WallpaperLease(string savePath){folder=Path.GetDirectoryName(savePath);recordPath=Path.Combine(folder,"wallpaper-session.json");}
 public static string Current {get{var b=new StringBuilder(32768);ReadWallpaper(0x73,(uint)b.Capacity,b,0);return b.ToString();}}
 public string Applied {get{return record==null?"":record.Applied;}}
 static void EngineCommand(string executable,string command){if(string.IsNullOrEmpty(executable)||!File.Exists(executable))return;using(var p=Process.Start(new ProcessStartInfo(executable,"-control "+command){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden})){p.WaitForExit(2000);}}
 public void Start(Bitmap landscape){if(active){Refresh(landscape);return;}Directory.CreateDirectory(folder);record=new Record{Original=Current};if(File.Exists(recordPath)){try{var previous=new JavaScriptSerializer().Deserialize<Record>(File.ReadAllText(recordPath));if(previous.Active&&string.Equals(previous.Applied,Current,StringComparison.OrdinalIgnoreCase))record=previous;}catch{}}
  foreach(string name in new[]{"wallpaper64","wallpaper32"})foreach(var process in Process.GetProcessesByName(name)){using(process){try{record.Engine=process.MainModule.FileName;}catch{}}}
  record.Active=true;active=true;Persist();try{EngineCommand(record.Engine,"stop");Refresh(landscape);}catch{Dispose();throw;}
 }
 void Persist(){File.WriteAllText(recordPath,new JavaScriptSerializer().Serialize(record));}
 public void Refresh(Bitmap landscape){if(!active)return;string target=Path.Combine(folder,"farm-wallpaper-"+(revision++%2)+".bmp");landscape.Save(target,System.Drawing.Imaging.ImageFormat.Bmp);record.Applied=target;Persist();if(!SystemParametersInfo(20,0,target,3))throw new InvalidOperationException("Windows wallpaper update failed: "+Marshal.GetLastWin32Error());if(!string.Equals(Current,target,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Windows did not accept the farm wallpaper");}
 public void Dispose(){if(!active)return;active=false;try{if(string.Equals(Current,record.Applied,StringComparison.OrdinalIgnoreCase)){if(!SystemParametersInfo(20,0,record.Original,3))throw new InvalidOperationException("Original wallpaper restore failed");}EngineCommand(record.Engine,"play");record.Active=false;Persist();}catch(Exception e){File.AppendAllText(Path.Combine(folder,"wallpaper-errors.log"),DateTime.Now+" "+e+Environment.NewLine);}}
}
}

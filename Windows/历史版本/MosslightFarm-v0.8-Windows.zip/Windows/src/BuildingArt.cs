using System.Drawing;
namespace DesktopFarm {
// Each workshop has its own silhouette and readable tools, even without colour.
public static class BuildingArt {
 static void R(Graphics g,string c,int x,int y,int w,int h){PixelArt.R(g,c,x,y,w,h);}
 static void P(Graphics g,string c,params int[] p){PixelArt.Poly(g,c,p);}
 static void Window(Graphics g,int x,int y,bool night,int w=10,int h=12){R(g,"574e42",x-1,y-1,w+2,h+2);R(g,night?"f7d78b":"83abb2",x,y,w,h);R(g,night?"fff0b9":"c2dad0",x+1,y+1,3,h-2);R(g,"a08561",x+w/2,y,1,h);R(g,"a08561",x,y+h/2,w,1);}
 static void Door(Graphics g,int x,int y,int w=12,int h=22){R(g,"564a40",x-1,y-1,w+2,h+1);R(g,"95704d",x,y,w,h);R(g,"c4a272",x+2,y+1,2,h-2);R(g,"e4cb83",x+w-3,y+h/2,1,2);}
 static void Base(Graphics g,int w,int h,string wall){PixelArt.Shadow(g,0,3,w+8);R(g,"655849",-w/2,-h,w,h+2);R(g,wall,-w/2+2,-h+2,w-4,h-2);R(g,"aa9874",-w/2,0,w,3);}
 static void Roof(Graphics g,int w,int y,int rise,string c){P(g,"514d44",-w/2,y,0,y-rise,w/2,y,w/2,y+5,-w/2,y+5);P(g,c,-w/2+3,y,0,y-rise+3,w/2-3,y);for(int i=4;i<rise;i+=5){int half=i*w/(rise*2);R(g,"c7c3a8",-half,y-rise+i,1,1);R(g,"b9b49a",-half+1,y-rise+i,half*2-2,1);}R(g,"dac39c",-w/2,y+3,w,2);}
 public static void Bakery(Graphics g,int x,int y,bool night){var s=g.Save();g.TranslateTransform(x,y);Base(g,72,39,"dcc89d");R(g,"66594a",23,-76,11,42);R(g,"bb8367",25,-74,7,38);for(int yy=-70;yy<-36;yy+=7)R(g,"e3b798",25,yy,7,1);R(g,"dfc2a0",21,-78,15,4);Roof(g,84,-39,26,"7b9494");Door(g,17,-24,12,24);Window(g,-29,-26,night,35,18);R(g,"806448",-32,-7,42,4);for(int i=0;i<3;i++){P(g,"b77b46",-27+i*11,-10,-27+i*11,-14,-24+i*11,-17,-20+i*11,-17,-17+i*11,-13,-17+i*11,-10);R(g,"edc681",-25+i*11,-15,6,4);R(g,"fff0b8",-23+i*11,-15,1,3);}R(g,"685b49",-35,-30,48,6);for(int i=0;i<8;i++)R(g,i%2==0?"f3dfb3":"ac6e59",-34+i*6,-29,6,7);R(g,"674e40",-9,-49,26,12);R(g,"e7cf9b",-8,-48,24,10);PixelArt.Item(g,"bread",4,-43,1);R(g,"9c7850",-39,-3,10,7);R(g,"d5b77f",-39,-4,10,2);g.Restore(s);}
 public static void Draw(Graphics g,int x,int y,string type,bool night){var s=g.Save();g.TranslateTransform(x,y);
 if(type=="barn"){
 Base(g,52,36,"b87560");P(g,"514b43",-31,-33,-20,-56,0,-65,20,-56,31,-33);P(g,"738989",-27,-35,-17,-53,0,-60,17,-53,27,-35);R(g,"b4c4b2",-20,-48,40,2);Door(g,-18,-27,36,27);for(int i=0;i<23;i++){R(g,"ead7af",-17+i,-25+i,2,2);R(g,"ead7af",16-i,-25+i,2,2);}R(g,"eddaba",-1,-26,2,27);Window(g,-5,-44,night,10,8);R(g,"cbbd8c",-30,0,12,6);for(int i=0;i<3;i++)R(g,"a4925f",-28+i*4,0,1,6);
 }else if(type=="coop"){
 PixelArt.Shadow(g,0,4,58);R(g,"6d5842",-20,-5,4,11);R(g,"6d5842",17,-5,4,11);R(g,"66523f",-24,-29,48,27);R(g,"d6b67d",-22,-27,44,23);Roof(g,56,-29,19,"8b965f");R(g,"5a4b3d",-9,-18,17,15);R(g,"423f34",-6,-16,11,13);P(g,"c2a477",-7,-3,7,-3,16,12,-1,12);for(int i=0;i<4;i++)R(g,"8e7552",-5+i*2,i*3,13,1);Window(g,13,-21,night,6,6);R(g,"9d7950",-29,-6,13,6);R(g,"ead7a0",-28,-6,11,2);R(g,"fff0ce",-25,-10,4,4);R(g,"fff0ce",-20,-9,3,3);
 }else if(type=="dairy"){
 Base(g,46,32,"e3ddbf");Roof(g,57,-32,22,"71949c");Door(g,-7,-23);Window(g,10,-22,night,8,12);R(g,"769593",-29,-28,13,29);R(g,"b5ccc1",-27,-27,9,27);R(g,"e1e7cd",-26,-26,3,24);R(g,"648481",-30,-29,15,3);R(g,"75918b",-28,-11,11,2);R(g,"799893",-17,-14,8,3);R(g,"d9d4b2",-9,-44,18,10);R(g,"6d8887",-3,-45,6,3);R(g,"fff1cd",-4,-42,8,7);R(g,"97b8b0",-4,-39,8,2);
 }else if(type=="loom"){
 Base(g,54,31,"c5ac8e");P(g,"534d45",-31,-28,-22,-48,8,-48,30,-28);P(g,"8e7d91",-27,-30,-20,-45,6,-45,26,-30);R(g,"b9a3ac",-22,-40,34,2);Door(g,13,-23);R(g,"5f5548",-24,-28,30,27);R(g,"8c7156",-22,-25,26,23);for(int i=0;i<10;i++)R(g,"e5d9b5",-20+i*2,-24,1,18);R(g,"b56f79",-20,-14,20,7);R(g,"ead3ab",-20,-10,20,2);R(g,"d0b184",-26,-24,34,3);R(g,"d0b184",-26,-2,34,3);R(g,"ad6679",-27,0,8,6);R(g,"cfb0b4",-17,0,8,6);R(g,"708e9a",-7,0,8,6);
 }else if(type=="sugarhouse"){
 Base(g,50,30,"c9ad7c");R(g,"685949",15,-65,10,39);R(g,"b47c5c",17,-63,6,35);for(int yy=-58;yy<-29;yy+=6)R(g,"deb693",17,yy,6,1);R(g,"dbc39c",13,-67,14,4);Roof(g,58,-30,15,"9c825d");Door(g,-6,-24);R(g,"826b49",-27,-16,14,16);R(g,"bb985f",-25,-15,10,14);R(g,"dac48b",-27,-17,14,3);R(g,"665d46",-27,-6,14,2);for(int i=0;i<3;i++){R(g,"6d8c51",-23+i*3,-37,2,20);R(g,"bfd180",-23+i*3,-32,2,2);}R(g,"e9dbac",10,-14,12,14);R(g,"a99a70",11,-14,10,2);R(g,"fff1c9",13,-10,6,6);
 }else if(type=="preserves"){
 Base(g,54,32,"e2c699");Roof(g,62,-32,24,"ab716d");Door(g,12,-24);Window(g,-23,-26,night,24,14);R(g,"72563f",-29,-12,33,4);for(int i=0;i<3;i++){R(g,"644c40",-26+i*10,-9,8,10);R(g,i==1?"dea457":"b76c79",-25+i*10,-8,6,7);R(g,"f2dcaa",-26+i*10,-10,8,3);R(g,"f3e4ba",-24+i*10,-5,4,3);}R(g,"9b7750",-26,2,26,4);R(g,"c3a170",-26,2,2,8);R(g,"c3a170",-2,2,2,8);R(g,"456d4e",21,-39,3,36);for(int i=0;i<5;i++){R(g,"7d9d5e",18+i%2*5,-37+i*7,7,4);R(g,"cb7585",22,-34+i*7,2,2);}
 }else if(type=="station"){
 Base(g,54,29,"dabd8b");Roof(g,62,-29,18,"77928a");Door(g,-7,-23);Window(g,-22,-22,night,10,12);Window(g,12,-22,night,10,12);R(g,"e8dfba",-5,-42,10,9);R(g,"505749",0,-41,1,5);R(g,"505749",0,-37,3,1);R(g,"655b4c",-29,8,58,2);R(g,"655b4c",-29,13,58,2);for(int i=0;i<8;i++)R(g,"ac956f",-27+i*7,7,2,9);
 }else{Base(g,48,30,"d5bc8d");Roof(g,58,-30,20,"8b967a");Door(g,-6,-22);}
 g.Restore(s);}
}
}

# Mosslight v0.7 · Independent Desktop Preview

Wallpaper Engine is no longer required or launched. Mosslight owns its desktop surface, with an embedded Microsoft WebView2 renderer. This is a single-player Windows desktop farm.

Unzip the entire folder and run MosslightFarm.exe. Keep the adjacent DLLs, assets and runtime folder. Choose Use as desktop. Windows 10/11 x64, .NET Framework 4.8 and WebView2 Runtime are required. If WebView2 is missing, run runtime/MicrosoftEdgeWebview2Setup.exe, then try desktop mode again. This signed Microsoft bootstrapper downloads the free runtime; the game works offline once prerequisites are installed.

Click plots to plant, water or harvest. Drag buildings, plots, trees and decorations directly. Use the bottom dock for seeds, storage, production, orders, construction and decoration. The corner gear includes Chinese/English, interface size, weather, lighting, power saving, autostart and reconnect.

Ctrl + Alt + F or launching the game again opens management. Closing management keeps an enabled wallpaper running. Use Save and exit in Settings or the tray menu to quit. Other live-wallpaper programs should be closed during testing.

Existing saves remain in %LOCALAPPDATA%\MosslightFarm\save.json. Desktop cache is in the desktop subfolder; local diagnostic logs are not uploaded. Do not share runtime caches or personal saves with testers. Moving the game requires re-enabling autostart at the new location.

Validation: the independent renderer runs with all Wallpaper Engine processes stopped, and harvesting was tested in its native preview window. The surface attaches to the Windows desktop host and acknowledges live frames. 156 existing game/save checks and 28 responsive-layout combinations passed. Final visibility beneath Explorer icons and native desktop mouse routing still require hands-on confirmation, as the automation tool cannot target the parented child window. Mixed-DPI displays, Explorer restart, sleep/resume and a second clean machine have not yet been fully tested. This is a compatibility test build, not a Steam-reviewed release.

WebView2 notices and license are included under licenses.

using System;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;
using System.Web.Script.Serialization;
namespace DesktopFarm {
public static class StartupManager {
 const string RunKey=@"Software\Microsoft\Windows\CurrentVersion\Run",ValueName="Mosslight Farm";

 public static string StartupCommand(string exe){return "\""+exe.Replace("\"","")+"\" --startup";}
 public static bool Enabled {get{try{using(var key=Registry.CurrentUser.OpenSubKey(RunKey)){return key!=null&&Convert.ToString(key.GetValue(ValueName))==StartupCommand(System.Windows.Forms.Application.ExecutablePath);}}catch{return false;}}}
 public static void SetEnabled(bool enabled){using(var key=Registry.CurrentUser.CreateSubKey(RunKey)){if(enabled)key.SetValue(ValueName,StartupCommand(System.Windows.Forms.Application.ExecutablePath));else key.DeleteValue(ValueName,false);}}

}
}

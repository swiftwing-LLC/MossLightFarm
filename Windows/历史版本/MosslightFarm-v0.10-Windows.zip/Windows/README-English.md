# Mosslight v0.10 · Independent Desktop Preview

Wallpaper Engine is no longer required or launched. Mosslight owns its desktop surface, with an embedded Microsoft WebView2 renderer. This is a single-player Windows desktop farm.

Unzip the entire folder and run MosslightFarm.exe. Keep the adjacent DLLs, assets and runtime folder. Choose Use as desktop. Windows 10/11 x64, .NET Framework 4.8 and WebView2 Runtime are required. If WebView2 is missing, run runtime/MicrosoftEdgeWebview2Setup.exe, then try desktop mode again. This signed Microsoft bootstrapper downloads the free runtime; the game works offline once prerequisites are installed.

Click plots to plant, water or harvest. Drag buildings, plots, trees and decorations directly. Use the bottom dock for seeds, storage, production, orders, construction and decoration. The corner gear includes Chinese/English, interface size, weather, lighting, power saving, autostart and reconnect.

Ctrl + Alt + F or launching the game again opens management. Closing management keeps an enabled wallpaper running. Use Save and exit in Settings or the tray menu to quit. Other live-wallpaper programs should be closed during testing.

Existing saves migrate to %USERPROFILE%\Saved Games\MosslightFarm\save.json. Desktop cache is in the desktop subfolder; local diagnostic logs are not uploaded. Do not share runtime caches or personal saves with testers. Moving the game requires re-enabling autostart at the new location.

v0.10 adds timed construction and three visual tiers per building, two builders (three with a tier-three farmhouse), slower economy progression, a pannable 3 × 3-screen world, and purchasable River (2500 coins) and Lake (6000 coins) terrain. Drag empty land directly to pan. Drag objects directly to reposition them. Hold Shift while dragging to select Windows desktop icons. Carry objects farther by dragging to a screen edge. Return to farmhouse finds your moved home. Purchased terrains share one farm layout and switch for free. Water collisions block placement and incompatible terrain switches before charging.

Construction continues offline and finishes automatically. Buildings display cost and duration before purchase. Existing coins, inventory, building placement and farm level are preserved; XP is converted proportionally to the revised curve. Save format is now 2. Do not open it with older Windows builds or the macOS v0.8 source port. Rollback requires the matching pre-upgrade save backup.

Validation: 230 automated model/save/art checks pass, plus browser playtests for construction, offline completion after process restart, planting, processing, map purchase, mouse panning and saved building movement. 32 language/resolution/zoom combinations checked from 640×480 to 3840×2160. This is an initial economy tuning pass, not months of retention validation. Mixed-DPI displays, real reboot, Explorer restart, sleep/resume and other PCs still need compatibility testing. macOS remains a separately labeled v0.8 source port requiring Mac compilation and native acceptance testing. This is not a Steam-reviewed release.

WebView2 notices and license are included under licenses.


v0.10: drag empty ground directly to pan; outer trees and flower beds are movable saved objects. Animals use reachable local routes and advance with delivered frames. World-space butterflies, bees, songbirds and occasional geese remain in the landscape when the camera moves. Added flower beds and tree variants. Windows native preview drag checks passed using Computer Use; the registered desktop startup task is checked separately. These ambient species are decorative.

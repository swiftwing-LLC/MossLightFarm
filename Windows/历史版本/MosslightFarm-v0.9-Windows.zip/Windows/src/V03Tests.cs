﻿using System;
using System.Linq;
using System.IO;
using System.Drawing;
using System.Web.Script.Serialization;
namespace DesktopFarm {
public static class V03Tests {
 public static void Run(string path,Action<bool,string> check){var f=new Farm(()=>2000000000);var json=new JavaScriptSerializer();int coins=f.S.Coins;string crops=json.Serialize(f.S.Plots);
  check(FreeLayout.Objects(f,960,540).Count(o=>o.Kind=="plot")==12,"Every owned plot is an individually movable object");
  check(FreeLayout.Move(f,"plot:0",new Point(120,180),960,540),"A plot can move outside the original farm footprint");
  check(FreeLayout.Move(f,"cabin",new Point(440,170),960,540),"The house can move to the upper desktop");
  check(f.S.Coins==coins&&json.Serialize(f.S.Plots)==crops,"Moving owned objects never charges money or resets crop timers");
  var plot=FreeLayout.Objects(f,960,540).First(o=>o.Id=="plot:0");check(plot.Foot==new Point(120,180),"Moved plot rendering and hit target share its new coordinates");
  string oldLayout=json.Serialize(f.S.DesktopLayout);check(!FreeLayout.Move(f,"cabin",new Point(120,185),960,540)&&json.Serialize(f.S.DesktopLayout)==oldLayout,"Invalid overlap is rejected without altering the saved layout");
  string file=Path.Combine(path,"layout-save.json");f.Save(file);var restored=new Farm(()=>2000000010);restored.Load(file);check(restored.S.DesktopLayout.Count==2&&restored.S.DesktopLayout["plot:0"].X==.125,"Free layout survives save and restart");
  check(FreeLayout.Objects(restored,1920,1080).First(o=>o.Id=="plot:0").Foot==new Point(240,360),"Layout adapts proportionally to another screen size");
  f.BuyDecoration("path",390,185);var decoration=f.S.Decorations.Last();string id="decor:"+decoration.Key;check(f.S.Coins==coins-5&&decoration.Key.Length>0,"Paths are affordable and decorations have stable identities");
  check(FreeLayout.Move(f,id,new Point(700,170),960,540),"A newly purchased decoration can move anywhere on the desktop");
  Farm.Validate(f.S);check(f.S.DesktopLayout.ContainsKey(id),"Save validation preserves decoration layout identities");
  var animal=new Wanderer("cat",-1,new Point(55,110));animal.TargetX=145;animal.TargetY=110;var block=new Rectangle(80,90,40,40);bool entered=false;var random=new Random(8);for(int i=0;i<2000;i++){animal.Step(.1,new Rectangle(22,65,916,405),random,new[]{block});entered|=block.Contains((int)animal.X,(int)animal.Y);}check(!entered,"Companions route around moved object footprints");
  var interactive=new Farm(()=>2000000000);using(var screen=new WallpaperForm(interactive,s=>{},()=>{},true)){screen.EditMode=false;var tile=FreeLayout.Objects(interactive,960,540).First(o=>o.Id=="plot:0");double x=tile.Foot.X/960.0,y=(tile.Foot.Y-10)/540.0;screen.ClientInput("down",x,y);screen.ClientInput("up",x,y);check(interactive.S.Harvests==1&&interactive.S.Plots[0].Crop=="","Live wallpaper mouse input harvests directly");int money=interactive.S.Coins;screen.ClientInput("down",x,y);screen.ClientInput("up",x,y);check(interactive.S.Coins==money-Farm.Crop("wheat").Cost&&interactive.S.Plots[0].Crop=="wheat","Live wallpaper input replants and charges exactly once");screen.ClientInput("up",x,y);check(interactive.S.Coins==money-Farm.Crop("wheat").Cost,"An unmatched mouse release cannot repeat a game action");screen.ClientInput("down",x,y);screen.ClientInput("move",.16,.30);screen.ClientInput("up",.16,.30);check(interactive.S.DesktopLayout.ContainsKey("plot:0")&&interactive.S.Plots[0].Crop=="wheat","Live wallpaper dragging preserves a growing crop");}
  using(var scene=new WallpaperForm(f,s=>{},()=>{},true))using(var bitmap=scene.SceneSnapshot(960,540)){bitmap.Save(Path.Combine(path,"free-layout.png"));check(bitmap.Width==960&&bitmap.GetPixel(0,0).A==255,"Custom layouts render as a complete wallpaper");}
 }
}
}

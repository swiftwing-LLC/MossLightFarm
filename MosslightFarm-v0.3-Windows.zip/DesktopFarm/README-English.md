# Mosslight Desktop Farm · v0.3

A playable pixel farm on your Windows desktop. **Wallpaper Engine and Mosslight Farm must both be running for live wallpaper mode.** Management also works as a standalone window.

Run `MosslightFarm.exe` with the adjacent `assets` folder. Switch Chinese / English on the welcome screen or in Settings. Choose **Use as desktop**, then return to the Windows desktop.

- **Click a plot directly** to plant, harvest or water. No Alt key is needed.
- **Click companions** to pet them, or feed/collect from farm animals.
- **Drag any owned building, plot, pond, tree, fence or decoration** to move it. Layout is saved; moving preserves crop timers and does not cost money. Solid objects cannot overlap.
- **Arrange desktop** opens the decoration palette. Select an item, then click a spot to buy and place it. Choose **Finish arranging** to resume harvesting.
- **Ctrl + Alt + F**, the wheat tray icon or running the game again opens management.
- **Restore desktop** stops the farm wallpaper. **Save and quit** restores the previously selected Wallpaper Engine wallpaper.

The separate arrangement window shares your actual farm and layout. Its Space key switches play/arrange mode; Esc or right-click cancels placement. Management shows a compact farming overview; the wallpaper uses your custom arrangement.

Start by harvesting wheat, replanting, milling flour, and fulfilling orders. Nine crops, nine recipes, four production animals, a cat/dog companion, decorations, land expansion and offline progress are included. Mature crops never wither.

Progress is saved after actions and every 15 seconds to `%LOCALAPPDATA%\MosslightFarm\save.json`, with a `.bak` backup. Layout changes and language choices persist. The wallpaper runtime is generated under `Documents\MosslightFarm\web-wallpaper`; keep those files in place while playing. The live connection stays on 127.0.0.1; no account or internet access is required.

Wallpaper Engine may pause animation when another application is focused, maximized or fullscreen, according to its Performance settings. Returning to the desktop should resume it. Farming timers continue by real elapsed time. This release is single-player; it does not provide online co-op or trading.

All game art and music are original project assets. C# sources are included. Exit the game and run `build.ps1` to rebuild. `--self-test <folder>` runs isolated rule, layout and interaction checks; `--qa <folder>` uses a separate test farm.

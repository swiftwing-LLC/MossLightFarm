using System;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using System.IO;

namespace DesktopFarm {
public class Wanderer {
 public string Type;public int AnimalIndex=-1;public double X,Y,TargetX,TargetY,Rest,WalkTime;public int Direction=1;public double Speed=15;
 public Wanderer(string type,int index,Point home){Type=type;AnimalIndex=index;X=TargetX=home.X;Y=TargetY=home.Y;Speed=index<0?18:type=="chicken"?13:type=="bee"?23:8;}
 public void Step(double dt,Rectangle area,Random random,IList<Rectangle> blocks){dt=Math.Min(.2,Math.Max(0,dt));if(Rest>0){Rest-=dt;return;}double dx=TargetX-X,dy=TargetY-Y,dist=Math.Sqrt(dx*dx+dy*dy);if(dist<2){Rest=1+random.NextDouble()*5;Choose(area,random,blocks);return;}double step=Math.Min(dist,Speed*dt),nx=X+dx/dist*step,ny=Y+dy/dist*step;if(!blocks.Any(b=>b.Contains((int)X,(int)Y))&&blocks.Any(b=>b.Contains((int)nx,(int)ny))){Choose(area,random,blocks);Rest=.3;return;}X=Math.Max(area.Left,Math.Min(area.Right-1,nx));Y=Math.Max(area.Top,Math.Min(area.Bottom-1,ny));if(Math.Abs(dx)>.3)Direction=dx>0?1:-1;WalkTime+=dt;}
 public void Choose(Rectangle area,Random random,IList<Rectangle> blocks){for(int tries=0;tries<50;tries++){int x=random.Next(area.Left,area.Right),y=random.Next(area.Top,area.Bottom);if(!blocks.Any(b=>b.Contains(x,y))){TargetX=x;TargetY=y;return;}}TargetX=X;TargetY=Y;}
 public void MoveTo(Point p,Rectangle area){X=TargetX=Math.Max(area.Left,Math.Min(area.Right-1,p.X));Y=TargetY=Math.Max(area.Top,Math.Min(area.Bottom-1,p.Y));Rest=3;}
}
public class WallpaperForm:Form {
 readonly Farm farm;readonly Action<string> openPanel;readonly Action changed;readonly bool preview;readonly Timer ticker=new Timer(),inputTimer=new Timer();readonly Random random=new Random();readonly List<Wanderer> actors=new List<Wanderer>();
 readonly Font small=new Font("Microsoft YaHei UI",12,FontStyle.Regular,GraphicsUnit.Pixel),titleFont=new Font("Microsoft YaHei UI",15,FontStyle.Bold,GraphicsUnit.Pixel);
 DateTime last=DateTime.Now;double time=0,noteUntil=0,lastBind=0;int hover=-1;bool wasDown=false,dragging=false,closing=false,armed=false;Wanderer dragged;Point pressedAt;string note="";Point pointer;Rectangle farmBounds;int logicalWidth=960,logicalHeight=540;
 public string HostDetail="";public bool IsAttached {get{return !preview&&IsHandleCreated&&(DesktopHost.ClassName(DesktopHost.GetParent(Handle))=="WorkerW"||DesktopHost.ClassName(DesktopHost.GetParent(Handle))=="Progman");}}
 public WallpaperForm(Farm f,Action<string> open,Action onChanged,bool asPreview){farm=f;openPanel=open;changed=onChanged;preview=asPreview;Text="Mosslight — Desktop Landscape";DoubleBuffered=true;ShowInTaskbar=preview;FormBorderStyle=preview?FormBorderStyle.Sizable:FormBorderStyle.None;StartPosition=FormStartPosition.CenterScreen;BackColor=PixelArt.C("8fad69");
  var screen=GetScreen();if(preview){ClientSize=new Size(Math.Min(1200,screen.WorkingArea.Width-100),Math.Min(720,screen.WorkingArea.Height-100));MinimumSize=new Size(640,420);}else Bounds=screen.Bounds;
  ticker.Interval=66;ticker.Tick+=(s,e)=>TickScene();Shown+=(s,e)=>{if(!preview&&!IsAttached&&!Bind())Hide();};FormClosed+=(s,e)=>{ticker.Stop();};ticker.Start();if(!preview){inputTimer.Interval=50;inputTimer.Tick+=(s,e)=>{inputTimer.Interval=(DesktopHost.GetAsyncKeyState(0x12)&0x8000)!=0?16:80;PollPointer();};inputTimer.Start();}
 }
 protected override bool ShowWithoutActivation {get{return !preview;}}
 protected override CreateParams CreateParams {get{var p=base.CreateParams;if(!preview)p.ExStyle|=0x08000000|0x00000080;return p;}}
 Screen GetScreen(){var screens=Screen.AllScreens;return screens[Math.Max(0,Math.Min(screens.Length-1,farm.S.Monitor))];}
 public bool Bind(){Bounds=GetScreen().Bounds;bool result=DesktopHost.Attach(this,GetScreen().Bounds,out HostDetail);lastBind=time;return result;}
 public void Rebind(){if(!preview&&!Bind())Hide();}
 public void Announce(string text){note=text;noteUntil=time+5;Invalidate();}
 public void CallAnimals(){foreach(var a in actors){Point home=new Point(farmBounds.X+380+random.Next(-14,22),farmBounds.Y+210+random.Next(-20,30));a.TargetX=home.X;a.TargetY=home.Y;a.Rest=0;}Announce("小伙伴们正在慢慢回家。");}
 Rectangle RoamArea {get{return new Rectangle(22,56,Math.Max(10,logicalWidth-44),Math.Max(10,logicalHeight-100));}}
 void SyncActors(){string pet=farm.S.Pet=="dog"?"dog":"cat";if(actors.Count==0)actors.Add(new Wanderer(pet,-1,new Point(farmBounds.X+392,farmBounds.Y+219)));actors[0].Type=pet;for(int i=0;i<farm.S.Animals.Count;i++){int index=i;if(!actors.Any(a=>a.AnimalIndex==index))actors.Add(new Wanderer(farm.S.Animals[i].Type,i,new Point(farmBounds.X+205+i*37,farmBounds.Y+282)));}foreach(var a in actors){a.X=Math.Max(RoamArea.Left,Math.Min(RoamArea.Right-1,a.X));a.Y=Math.Max(RoamArea.Top,Math.Min(RoamArea.Bottom-1,a.Y));}}
 List<Rectangle> Obstacles(){var list=new List<Rectangle>{new Rectangle(212,127,169,154),new Rectangle(80,104,92,92),new Rectangle(395,95,61,94),new Rectangle(448,202,104,66),new Rectangle(20,113,54,76),new Rectangle(178,75,47,76),new Rectangle(527,103,52,75),new Rectangle(12,204,52,72),new Rectangle(544,195,50,75),new Rectangle(6,72,185,71),new Rectangle(440,63,138,82)};if(farm.Has("bakery"))list.Add(new Rectangle(47,177,73,86));if(farm.Has("coop"))list.Add(new Rectangle(145,215,53,52));if(farm.Has("barn"))list.Add(new Rectangle(397,217,50,50));foreach(var b in new[]{"loom","dairy","sugarhouse"})if(farm.Has(b))list.Add(new Rectangle(b=="loom"?207:b=="dairy"?265:324,69,43,50));for(int i=0;i<list.Count;i++){var b=list[i];b.Offset(farmBounds.Location);list[i]=b;}return list;}
 void TickScene(){if(closing)return;double dt=(DateTime.Now-last).TotalSeconds;last=DateTime.Now;time+=Math.Min(1,dt);SetLayout();SyncActors();var blocks=Obstacles();foreach(var a in actors)if(a!=dragged){bool pointing=(preview||(DesktopHost.GetAsyncKeyState(0x12)&0x8000)!=0)&&Math.Abs(a.X-pointer.X)<22&&pointer.Y>a.Y-30&&pointer.Y<a.Y+10;if(!pointing)a.Step(dt,RoamArea,random,blocks);}if(!preview){if(time-lastBind>4){lastBind=time;if(!IsAttached||!DesktopHost.IsWindow(DesktopHost.GetParent(Handle)))Bind();}}ticker.Interval=farm.S.Quiet?160:(!preview&&!DesktopHost.DesktopForeground?160:66);Invalidate();}
 void SetLayout(){int pixel=Math.Max(1,Math.Min(ClientSize.Width/960,ClientSize.Height/540));logicalWidth=Math.Max(640,ClientSize.Width/pixel);logicalHeight=Math.Max(340,ClientSize.Height/pixel);farmBounds=new Rectangle((logicalWidth-600)/2,logicalHeight-308,600,300);}
 Point Logical(Point client){return new Point((int)(client.X*logicalWidth/(double)Math.Max(1,ClientSize.Width)),(int)(client.Y*logicalHeight/(double)Math.Max(1,ClientSize.Height)));}
 void PollPointer(){Point screen=Cursor.Position;pointer=Logical(PointToClient(screen));bool alt=(DesktopHost.GetAsyncKeyState(0x12)&0x8000)!=0;bool down=(DesktopHost.GetAsyncKeyState(1)&0x8000)!=0;bool usable=DesktopHost.DesktopUnderPointer(screen,Handle)&&ClientRectangle.Contains(PointToClient(screen));hover=usable&&alt?PlotAt(pointer):-1;
  if(alt&&usable&&down&&!wasDown){Begin(pointer);armed=true;}if(down&&dragged!=null){if(Distance(pointer,pressedAt)>5)dragging=true;if(dragging)dragged.MoveTo(pointer,RoamArea);}if(!down&&wasDown){if(armed&&alt&&usable)End(pointer);else{dragged=null;dragging=false;}armed=false;}wasDown=down;
 }
 static double Distance(Point a,Point b){return Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));}
 int PlotAt(Point p){int x=p.X-farmBounds.X-224,y=p.Y-farmBounds.Y-141;if(x<0||y<0||x>=144||y>=138)return -1;return y/23*6+x/24;}
 void Begin(Point p){pressedAt=p;dragging=false;dragged=actors.LastOrDefault(a=>Math.Abs(a.X-p.X)<22&&p.Y>a.Y-30&&p.Y<a.Y+10);}
 void End(Point p){if(dragged!=null){if(!dragging){Announce(dragged.AnimalIndex<0?farm.Pet():farm.AnimalAction(dragged.AnimalIndex));changed();}else Announce("放在这里，它会继续自由散步。");dragged=null;dragging=false;return;}
  if(new Rectangle(logicalWidth-176,14,156,34).Contains(p)){openPanel("settings");return;}if(new Rectangle(logicalWidth-342,14,156,34).Contains(p)){openPanel("");return;}
  int plot=PlotAt(p);if(plot>=0){if(plot>=farm.S.Plots.Count){openPanel("build");return;}var crop=farm.S.Plots[plot];string result;if(crop.Crop=="")result=farm.Plant(plot,farm.S.SelectedSeed);else if(crop.Ready<=farm.Now)result=farm.Harvest(plot);else result=farm.Water(plot);Announce(result);changed();return;}
  var q=new Point(p.X-farmBounds.X,p.Y-farmBounds.Y);if(new Rectangle(383,87,81,111).Contains(q)||new Rectangle(44,177,77,90).Contains(q)&&farm.Has("bakery")){openPanel("workshop");return;}if(new Rectangle(75,100,106,105).Contains(q)){openPanel("journal");return;}if(q.X>137&&q.X<206&&q.Y>213){openPanel("pet");return;}
 }
 protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);pointer=Logical(e.Location);hover=PlotAt(pointer);if(preview&&dragged!=null&&(e.Button&MouseButtons.Left)!=0){if(Distance(pointer,pressedAt)>5)dragging=true;if(dragging)dragged.MoveTo(pointer,RoamArea);}}
 protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(preview&&e.Button==MouseButtons.Left)Begin(Logical(e.Location));}
 protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);if(preview&&e.Button==MouseButtons.Left)End(Logical(e.Location));}
 void Label(Graphics g,string text,Rectangle r,bool bold){using(var b=new SolidBrush(PixelArt.C("f7f1dc")))using(var sf=new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center,Trimming=StringTrimming.EllipsisCharacter})g.DrawString(L.T(text),bold?titleFont:small,b,r,sf);}
 public Bitmap SceneSnapshot(int width,int height){int oldW=logicalWidth,oldH=logicalHeight;Rectangle old=farmBounds;logicalWidth=width;logicalHeight=height;farmBounds=new Rectangle((width-600)/2,height-308,600,300);SyncActors();var bitmap=DrawScene();logicalWidth=oldW;logicalHeight=oldH;farmBounds=old;return bitmap;}
 Bitmap DrawScene(){var b=PixelArt.Wallpaper(farm,time,logicalWidth,logicalHeight,hover);using(var g=Graphics.FromImage(b)){g.SmoothingMode=SmoothingMode.None;foreach(var a in actors.OrderBy(x=>x.Y)){if(a.AnimalIndex<0)PixelArt.Cat(g,(int)a.X,(int)a.Y,a.WalkTime,a.Type=="dog",a.Rest>3,a.Direction,farm.Now-farm.S.LastPet<4);else if(a.Type=="bee"){for(int i=0;i<3;i++){int x=(int)a.X+(int)(Math.Sin(time*3+i*2)*7),y=(int)a.Y+(int)(Math.Cos(time*2+i)*5);PixelArt.R(g,"ebeed3",x,y-3,3,2);PixelArt.R(g,"e5bb63",x,y,5,3);PixelArt.R(g,"675443",x+2,y,1,3);}}else{var s=g.Save();g.TranslateTransform((int)a.X,(int)a.Y);g.ScaleTransform(a.Direction,1);PixelArt.Animal(g,0,0,a.Type,a.WalkTime,a.Rest>2);g.Restore(s);}if(a.AnimalIndex>=0){var animal=farm.S.Animals[a.AnimalIndex];if(animal.Fed&&animal.Ready<=farm.Now){PixelArt.R(g,"f6ebc3",(int)a.X-4,(int)a.Y-34,10,8);PixelArt.R(g,"719369",(int)a.X,(int)a.Y-32,2,4);}}}
  g.TextRenderingHint=TextRenderingHint.AntiAliasGridFit;using(var brush=new SolidBrush(Color.FromArgb(220,61,82,65))){g.FillRectangle(brush,logicalWidth-342,14,156,34);g.FillRectangle(brush,logicalWidth-176,14,156,34);g.FillRectangle(brush,18,logicalHeight-29,logicalWidth-36,23);}
  Label(g,"打开农场",new Rectangle(logicalWidth-342,14,156,34),false);Label(g,"设置 / 语言",new Rectangle(logicalWidth-176,14,156,34),false);
  Label(g,preview?"背景预览 · 直接点击互动 / 拖动小动物":"Alt + 单击田地或动物 · Alt + 拖动动物 · Ctrl + Alt + F 打开农场",new Rectangle(24,logicalHeight-28,logicalWidth-48,22),false);
  if(time<noteUntil){using(var br=new SolidBrush(Color.FromArgb(235,60,80,63)))g.FillRectangle(br,logicalWidth/2-245,logicalHeight-70,490,32);Label(g,note,new Rectangle(logicalWidth/2-237,logicalHeight-70,474,32),false);}
 }return b;}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);SetLayout();SyncActors();using(var b=DrawScene()){e.Graphics.InterpolationMode=InterpolationMode.NearestNeighbor;e.Graphics.PixelOffsetMode=PixelOffsetMode.Half;e.Graphics.DrawImage(b,ClientRectangle);}}
 protected override void Dispose(bool disposing){if(disposing&&!closing){closing=true;ticker.Stop();ticker.Dispose();inputTimer.Stop();inputTimer.Dispose();if(!preview&&IsHandleCreated)DesktopHost.Detach(this);small.Dispose();titleFont.Dispose();}base.Dispose(disposing);}
}
}

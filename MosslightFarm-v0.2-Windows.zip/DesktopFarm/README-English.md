# Mosslight Desktop Farm · v0.2

A quiet pixel farm that lives behind your Windows desktop icons.

Run **MosslightFarm.exe**, keeping the adjacent `assets` folder. Choose **中文 / English** on the welcome screen, or change the language in Settings. No account, installation or internet connection is required.

## Make it your background

Choose **Settings → Use as desktop**. Pets and unlocked farm animals explore the screen. Normal desktop clicks continue working.

- **Alt + click a plot** to plant, harvest, or water. Planting uses the seed selected in management.
- **Alt + click a companion** to pet it or feed/collect from a farm animal.
- **Alt + drag a companion** to move it; it resumes wandering afterward.
- **Ctrl + Alt + F** opens management or returns to the landscape.
- Double-click the wheat tray icon, or run the game again, to open management.
- **Restore desktop** removes the landscape. **Save and quit** exits and restores your original desktop.
- **Preview landscape** supports direct clicks and dragging in a window. It shares your real farm progress.

The game does not edit your wallpaper file, desktop files or icon positions. The landscape runs on one selected monitor. It does not start automatically with Windows.

## Your first harvest

Harvest golden wheat, claim the journal reward, and replant. Each plot yields three items. The mill converts two wheat into flour in 45 seconds. Sell goods in Storage or fulfill neighbor orders. At level 2, unlock corn, a bakery, a chicken coop and your first expansion.

There are nine crops, nine production recipes, four farm animal types, a cat/dog companion, decorations and two land expansions. Mature crops never wither. Production completes by real elapsed time, including while the game is closed.

Progress saves after actions and every 15 seconds to `%LOCALAPPDATA%\MosslightFarm\save.json`, with a `.bak` backup. Changing language preserves progress. Music and sound are optional. Automatic weather is a local simulation; daylight follows your clock.

This is a playable single-player release. Town storylines, additional languages and online trading are not included. Tested on this Windows computer at 3840 × 2160; other Windows releases and mixed-DPI multi-monitor setups require further compatibility testing.

Full C# sources and the original audio generator are included. Exit the game and run `build.ps1` to rebuild with the Windows .NET Framework compiler. `--self-test <folder>` checks game rules and layouts using isolated data. `--qa <folder>` starts a separate test farm. All art and music are original project assets.
